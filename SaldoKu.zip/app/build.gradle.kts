plugins {
    alias(libs.plugins.android.application)
}

android {
    namespace = "com.saldo.kim"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.saldo.kim"
        minSdk = 28 // Tetap 28 (Android 9) udah aman banget buat fitur PDF
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    
    compileOptions {
        // Kita kunci di Java 11, tapi pastikan JStudio Mamang dukung
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }
}

dependencies {
    // Gunakan notasi single-string (libs) seperti ini sudah benar
    implementation(libs.androidx.appcompat)
    implementation(libs.material)
    implementation(libs.androidx.constraintlayout)
    implementation(libs.androidx.activity)
    
    // Testing
    testImplementation(libs.junit)
    androidTestImplementation(libs.androidx.junit)
    androidTestImplementation(libs.androidx.espresso.core)
}