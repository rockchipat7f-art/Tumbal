package com.saldo.kim;

public class Transaksi {
    public int id; // Tambahkan ID
    public String keterangan, tanggal;
    public long nominal;

    public Transaksi(int id, String keterangan, long nominal, String tanggal) {
        this.id = id;
        this.keterangan = keterangan;
        this.nominal = nominal;
        this.tanggal = tanggal;
    }
}