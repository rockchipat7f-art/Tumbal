package com.saldo.kim;

import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.FileProvider;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class KantongFragment extends Fragment {

    private RecyclerView rvKantong;
    private KantongAdapter adapter;
    private List<Kantong> listKantong = new ArrayList<>();
    private DatabaseHelper dbHelper;
    private TextView tvTotalSemua;
    private Button btnExport;
    private FloatingActionButton fabTambah;
    private View rootLayout;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_kantong, container, false);

        rootLayout = view;
        rvKantong = view.findViewById(R.id.rv_kantong);
        tvTotalSemua = view.findViewById(R.id.tv_total_semua_kantong);
        btnExport = view.findViewById(R.id.btn_export_laporan);
        fabTambah = view.findViewById(R.id.fab_tambah_kantong);

        dbHelper = new DatabaseHelper(getContext());

        rvKantong.setLayoutManager(new LinearLayoutManager(getContext()));
        
        updateBackgroundMode(); 
        muatDataKantong();

        // AKSI TOMBOL EXPORT
        btnExport.setOnClickListener(v -> {
            if (listKantong.isEmpty()) {
                Toast.makeText(getContext(), "Gak ada data buat dilacak, Wak!", Toast.LENGTH_SHORT).show();
            } else {
                exportKePDF();
            }
        });

        fabTambah.setOnClickListener(v -> {
            showDialogInputKantong(null); 
        });

        return view;
    }

    // --- FUNGSI EXPORT PDF (MONITOR SALDO TERLACAK) ---
    private void exportKePDF() {
        PdfDocument pdfDocument = new PdfDocument();
        Paint paint = new Paint();
        Paint titlePaint = new Paint();

        // Ukuran A4 (595 x 842)
        PdfDocument.PageInfo pageInfo = new PdfDocument.PageInfo.Builder(595, 842, 1).create();
        PdfDocument.Page page = pdfDocument.startPage(pageInfo);
        Canvas canvas = page.getCanvas();

        // 1. Header & Slogan Kesepakatan
        titlePaint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        titlePaint.setTextSize(24);
        titlePaint.setColor(Color.parseColor("#0288D1")); 
        canvas.drawText("MONITOR SALDO TERLACAK", 40, 70, titlePaint);

        paint.setTextSize(12);
        // REVISI: Menggunakan setTypeface untuk miring (Italic)
        paint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.ITALIC));
        paint.setColor(Color.parseColor("#757575"));
        canvas.drawText("\"Duit Gak Bakal Ngilang Tanpa Jejak!\"", 40, 92, paint);

        // Balikin ke Normal untuk teks lainnya
        paint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.NORMAL));
        paint.setTextSize(10);
        paint.setColor(Color.BLACK);
        String tgl = new SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(new Date());
        canvas.drawText("Dicetak: " + tgl, 430, 70, paint);

        paint.setColor(Color.parseColor("#0288D1"));
        paint.setStrokeWidth(3);
        canvas.drawLine(40, 110, 555, 110, paint);

        // 2. Ringkasan Total Saldo
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.parseColor("#F0F0F0"));
        canvas.drawRect(40, 130, 555, 195, paint);

        paint.setColor(Color.BLACK);
        paint.setTextSize(13);
        paint.setFakeBoldText(true);
        canvas.drawText("REKAPITULASI TOTAL SALDO:", 60, 155, paint);
        
        titlePaint.setTextSize(24);
        titlePaint.setColor(Color.parseColor("#4CAF50")); 
        canvas.drawText(tvTotalSemua.getText().toString(), 60, 185, titlePaint);

        // 3. Tabel Data Kantong
        int startX = 40;
        int startY = 230;
        
        paint.setColor(Color.parseColor("#0288D1"));
        canvas.drawRect(startX, startY, 555, startY + 30, paint);

        paint.setColor(Color.WHITE);
        paint.setTextSize(12);
        canvas.drawText("NO", startX + 10, startY + 20, paint);
        canvas.drawText("NAMA KANTONG", startX + 50, startY + 20, paint);
        canvas.drawText("STATUS", startX + 300, startY + 20, paint);
        canvas.drawText("SALDO", startX + 420, startY + 20, paint);

        paint.setColor(Color.BLACK);
        paint.setFakeBoldText(false);
        int currentY = startY + 30;
        
        for (int i = 0; i < listKantong.size(); i++) {
            Kantong k = listKantong.get(i);
            currentY += 28;
            
            if (i % 2 == 1) {
                Paint bgPaint = new Paint();
                bgPaint.setColor(Color.parseColor("#FAFAFA"));
                canvas.drawRect(startX, currentY - 20, 555, currentY + 8, bgPaint);
            }

            canvas.drawText(String.valueOf(i + 1), startX + 10, currentY, paint);
            canvas.drawText(k.nama, startX + 50, currentY, paint);
            canvas.drawText(k.isUtama == 1 ? "Utama" : "-", startX + 300, currentY, paint);
            
            DecimalFormat df = new DecimalFormat("#,###");
            String formattedSaldo = "Rp " + df.format(k.saldo).replace(",", ".");
            canvas.drawText(formattedSaldo, startX + 420, currentY, paint);

            paint.setStrokeWidth(0.5f);
            paint.setAlpha(80);
            canvas.drawLine(startX, currentY + 8, 555, currentY + 8, paint);
            paint.setAlpha(255);
        }

        pdfDocument.finishPage(page);

        // 4. Simpan ke Cache & Share
        File cachePath = new File(getContext().getCacheDir(), "pdf_reports");
        if (!cachePath.exists()) cachePath.mkdirs();
        File file = new File(cachePath, "Laporan_Monitor_Saldo.pdf");

        try {
            pdfDocument.writeTo(new FileOutputStream(file));
            pdfDocument.close();
            shareFile(file);
        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(getContext(), "Gagal: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private void shareFile(File file) {
        Uri uri = FileProvider.getUriForFile(getContext(), getContext().getPackageName() + ".fileprovider", file);
        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType("application/pdf");
        intent.putExtra(Intent.EXTRA_STREAM, uri);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivity(Intent.createChooser(intent, "Kirim Laporan Monitor Saldo"));
    }

    private void showDialogInputKantong(@Nullable Kantong k) {
        final EditText etNama = new EditText(getContext());
        etNama.setHint("Nama Kantong (Misal: Uang Makan)");
        etNama.setSingleLine(true);
        if (k != null) etNama.setText(k.nama);

        FrameLayout container = new FrameLayout(getContext());
        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        params.leftMargin = 60; params.rightMargin = 60; params.topMargin = 20;
        etNama.setLayoutParams(params);
        container.addView(etNama);

        String title = (k == null) ? "Tambah Kantong" : "Ubah Nama Kantong";

        new AlertDialog.Builder(getContext())
                .setTitle(title)
                .setView(container)
                .setPositiveButton("Simpan", (dialog, which) -> {
                    String nama = etNama.getText().toString().trim();
                    if (!nama.isEmpty()) {
                        if (k == null) simpanKantongBaru(nama);
                        else updateNamaKantong(k.id, nama);
                    }
                })
                .setNegativeButton("Batal", null)
                .show();
    }

    private void simpanKantongBaru(String nama) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues v = new ContentValues();
        v.put("nama_kantong", nama);
        v.put("saldo", 0);
        v.put("is_utama", 0);
        db.insert("table_kantong", null, v);
        muatDataKantong();
        Toast.makeText(getContext(), "Kantong '" + nama + "' dibuat!", Toast.LENGTH_SHORT).show();
    }

    private void updateNamaKantong(int id, String namaBaru) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues v = new ContentValues();
        v.put("nama_kantong", namaBaru);
        db.update("table_kantong", v, "id=?", new String[]{String.valueOf(id)});
        muatDataKantong();
    }

    public void muatDataKantong() {
        listKantong.clear();
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM table_kantong", null);
        if (cursor.moveToFirst()) {
            do {
                listKantong.add(new Kantong(
                        cursor.getInt(0),
                        cursor.getString(1),
                        cursor.getLong(2),
                        cursor.getInt(3)
                ));
            } while (cursor.moveToNext());
        }
        cursor.close();

        adapter = new KantongAdapter(listKantong, getContext());
        adapter.setOnItemLongClickListener(this::showOpsiKantong); 
        rvKantong.setAdapter(adapter);

        updateTotalHeader();
    }

    private void showOpsiKantong(Kantong k) {
        String[] menu = {"Ubah Nama", "Hapus Kantong"};
        new AlertDialog.Builder(getContext())
                .setTitle("Opsi: " + k.nama)
                .setItems(menu, (dialog, which) -> {
                    if (which == 0) showDialogInputKantong(k);
                    else hapusKantong(k);
                }).show();
    }

    private void hapusKantong(Kantong k) {
        if (k.isUtama == 1) {
            Toast.makeText(getContext(), "Kantong Utama gak bisa dihapus, Wak!", Toast.LENGTH_SHORT).show();
            return;
        }

        new AlertDialog.Builder(getContext())
                .setTitle("Hapus Kantong")
                .setMessage("Yakin hapus '" + k.nama + "'? Riwayat di dalamnya juga bakal hilang!")
                .setPositiveButton("Hapus", (d, w) -> {
                    SQLiteDatabase db = dbHelper.getWritableDatabase();
                    db.delete("table_kantong", "id=?", new String[]{String.valueOf(k.id)});
                    db.delete("table_transaksi", "id_kantong=?", new String[]{String.valueOf(k.id)});
                    muatDataKantong();
                    Toast.makeText(getContext(), "Terhapus!", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("Batal", null)
                .show();
    }

    private void updateTotalHeader() {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT SUM(saldo) FROM table_kantong", null);
        long total = 0;
        if (cursor.moveToFirst()) total = cursor.getLong(0);
        cursor.close();

        DecimalFormatSymbols symbols = new DecimalFormatSymbols();
        symbols.setGroupingSeparator('.');
        DecimalFormat df = new DecimalFormat("#,###", symbols);
        tvTotalSemua.setText("Rp. " + df.format(total));
    }

    private void updateBackgroundMode() {
        int nightModeFlags = getContext().getResources().getConfiguration().uiMode & android.content.res.Configuration.UI_MODE_NIGHT_MASK;
        if (nightModeFlags == android.content.res.Configuration.UI_MODE_NIGHT_YES) {
            rootLayout.setBackgroundColor(Color.parseColor("#212121"));
        } else {
            rootLayout.setBackgroundColor(Color.parseColor("#F5F5F5"));
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        muatDataKantong();
    }
}