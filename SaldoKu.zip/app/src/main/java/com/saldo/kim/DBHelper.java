package com.saldo.kim;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "SaldoKu.db";
    private static final int DATABASE_VERSION = 2; // Naik ke versi 2 karena ada perubahan struktur

    public DBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // 1. Tabel untuk menyimpan daftar Kantong
        db.execSQL("CREATE TABLE table_kantong (id INTEGER PRIMARY KEY AUTOINCREMENT, nama TEXT, saldo INTEGER, is_utama INTEGER)");

        // 2. Isi data awal (Default) agar aplikasi tidak kosong saat pertama instal
        db.execSQL("INSERT INTO table_kantong (nama, saldo, is_utama) VALUES ('Dana', 0, 1)");
        db.execSQL("INSERT INTO table_kantong (nama, saldo, is_utama) VALUES ('BRI', 0, 0)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Jika user update aplikasi, tabel lama dihapus dan buat baru (Sederhananya begitu)
        db.execSQL("DROP TABLE IF EXISTS table_kantong");
        onCreate(db);
    }

    // --- FUNGSI UNTUK WIDGET ---

    // Ambil Nama Kantong yang sedang aktif (Utama)
    public String getNamaKantongUtama() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT nama FROM table_kantong WHERE is_utama = 1", null);
        if (cursor.moveToFirst()) {
            String nama = cursor.getString(0);
            cursor.close();
            return nama;
        }
        return "Kantong";
    }

    // Ambil Saldo dari Kantong yang sedang aktif
    public int getSaldo() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT saldo FROM table_kantong WHERE is_utama = 1", null);
        if (cursor.moveToFirst()) {
            int saldo = cursor.getInt(0);
            cursor.close();
            return saldo;
        }
        return 0;
    }

    // Update saldo pada Kantong yang sedang aktif (Digunakan oleh tombol Masuk/Keluar di Widget)
    public void updateSaldo(int nominal) {
        SQLiteDatabase db = this.getWritableDatabase();
        // Ambil saldo lama dulu
        int saldoSekarang = getSaldo();
        int saldoBaru = saldoSekarang + nominal;

        ContentValues values = new ContentValues();
        values.put("saldo", saldoBaru);

        // Update hanya pada kantong yang is_utama = 1
        db.update("table_kantong", values, "is_utama = ?", new String[]{"1"});
    }

    // --- FUNGSI UNTUK HALAMAN KANTONG (DASHBOARD) ---

    // Fungsi untuk mengganti Kantong Utama
    public void setKantongUtama(int idKantong) {
        SQLiteDatabase db = this.getWritableDatabase();
        // Reset semua jadi 0 (tidak utama)
        db.execSQL("UPDATE table_kantong SET is_utama = 0");
        // Set id yang dipilih jadi 1 (utama)
        db.execSQL("UPDATE table_kantong SET is_utama = 1 WHERE id = " + idKantong);
    }

    // Tambah Kantong Baru
    public void tambahKantong(String nama, int saldoAwal) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("nama", nama);
        values.put("saldo", saldoAwal);
        values.put("is_utama", 0);
        db.insert("table_kantong", null, values);
    }
}