package com.saldo.kim;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    // Versi naik ke 4 karena tambah kolom id_kantong
    private static final String DATABASE_NAME = "SaldoQu_Terlacak.db";
    private static final int DATABASE_VERSION = 4; 

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // 1. Tabel Kantong
        db.execSQL("CREATE TABLE table_kantong (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "nama_kantong TEXT, " +
                "saldo LONG, " +
                "is_utama INTEGER)"); 

        // 2. Tabel Riwayat Transaksi (DITAMBAH id_kantong)
        db.execSQL("CREATE TABLE table_transaksi (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "keterangan TEXT, " +
                "nominal LONG, " +
                "id_kantong INTEGER, " + // <--- Ini kunci buat filter riwayat per kantong
                "tanggal DATETIME DEFAULT (datetime('now', 'localtime')))");

        // --- DATA AWAL ---
        
        // Kantong 1: Tabungan Utama
        ContentValues v1 = new ContentValues();
        v1.put("nama_kantong", "Tabungan Utama");
        v1.put("saldo", 0);
        v1.put("is_utama", 1); 
        db.insert("table_kantong", null, v1);

        // Kantong 2: Dana
        ContentValues v2 = new ContentValues();
        v2.put("nama_kantong", "Dana / E-Wallet");
        v2.put("saldo", 0);
        v2.put("is_utama", 0);
        db.insert("table_kantong", null, v2);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Hapus tabel lama dan buat ulang kalau versi naik
        db.execSQL("DROP TABLE IF EXISTS table_kantong");
        db.execSQL("DROP TABLE IF EXISTS table_transaksi");
        onCreate(db);
    }
}