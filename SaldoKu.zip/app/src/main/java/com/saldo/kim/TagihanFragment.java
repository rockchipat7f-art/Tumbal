package com.saldo.kim;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.fragment.app.Fragment;

public class TagihanFragment extends Fragment {
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Ini akan memanggil layout XML-nya nanti
        return inflater.inflate(R.layout.fragment_tagihan, container, false);
    }
}