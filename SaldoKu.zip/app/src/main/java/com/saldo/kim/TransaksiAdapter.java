package com.saldo.kim;

import android.graphics.Color;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class TransaksiAdapter extends RecyclerView.Adapter<TransaksiAdapter.ViewHolder> {
    private List<Transaksi> list;
    private OnItemClickListener listener;

    public interface OnItemClickListener {
        void onItemClick(Transaksi transaksi);
        void onItemLongClick(Transaksi transaksi);
    }

    public TransaksiAdapter(List<Transaksi> list, OnItemClickListener listener) { 
        this.list = list; 
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_transaksi, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Transaksi t = list.get(position);
        
        DecimalFormat df = new DecimalFormat("#,###");
        // Gunakan Math.abs biar tanda minus (-) gak double saat kita tambahkan manual
        String formattedNominal = "Rp. " + df.format(Math.abs(t.nominal)).replace(',', '.');

        holder.tvKet.setText(t.keterangan);

        // --- 1. LOGIKA FORMAT TANGGAL ---
        try {
            SimpleDateFormat sdfDatabase = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
            Date date = sdfDatabase.parse(t.tanggal);
            SimpleDateFormat sdfTampilan = new SimpleDateFormat("EEEE, dd MMM, HH:mm", new Locale("id", "ID"));
            holder.tvTgl.setText(sdfTampilan.format(date));
        } catch (Exception e) {
            holder.tvTgl.setText(t.tanggal);
        }

        // --- 2. LOGIKA WARNA NOMINAL & INDIKATOR ---
        // Warna ini statis (Hijau/Merah) karena aman di background putih maupun aspal
        if (t.nominal > 0) {
            holder.tvNom.setText("+ " + formattedNominal);
            holder.tvNom.setTextColor(Color.parseColor("#4CAF50")); // Hijau
            holder.indicator.setBackgroundColor(Color.parseColor("#4CAF50"));
        } else if (t.nominal < 0) {
            holder.tvNom.setText("- " + formattedNominal);
            holder.tvNom.setTextColor(Color.parseColor("#F44336")); // Merah
            holder.indicator.setBackgroundColor(Color.parseColor("#F44336"));
        } else {
            holder.tvNom.setText(formattedNominal);
            holder.tvNom.setTextColor(getAttributeColor(holder.itemView.getContext(), android.R.attr.textColorPrimary));
            holder.indicator.setBackgroundColor(Color.GRAY);
        }

        // --- 3. LOGIKA KLIK (EDIT & HAPUS) ---
        holder.itemView.setOnClickListener(v -> {
            if (listener != null) listener.onItemClick(t);
        });

        holder.itemView.setOnLongClickListener(v -> {
            if (listener != null) listener.onItemLongClick(t);
            return true;
        });
    }

    @Override
    public int getItemCount() { return list.size(); }

    // Fungsi sakti buat ngambil warna otomatis dari tema HP
    private int getAttributeColor(android.content.Context context, int attributeId) {
        TypedValue typedValue = new TypedValue();
        context.getTheme().resolveAttribute(attributeId, typedValue, true);
        return typedValue.data;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvKet, tvNom, tvTgl;
        View indicator;
        public ViewHolder(View v) {
            super(v);
            tvKet = v.findViewById(R.id.tv_keterangan);
            tvNom = v.findViewById(R.id.tv_nominal);
            tvTgl = v.findViewById(R.id.tv_tanggal);
            indicator = v.findViewById(R.id.indicator_type);
        }
    }
}