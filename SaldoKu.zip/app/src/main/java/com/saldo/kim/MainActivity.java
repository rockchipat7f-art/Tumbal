package com.saldo.kim;

import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import android.view.MenuItem;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Inisialisasi Bottom Navigation dari layout XML
        BottomNavigationView bottomNav = findViewById(R.id.bottom_navigation);

        // 1. Set halaman yang pertama kali muncul saat aplikasi dibuka (Home)
        if (savedInstanceState == null) {
            getSupportFragmentManager().beginTransaction()
                .replace(R.id.fragment_container, new HomeFragment())
                .commit();
        }

        // 2. Logika ketika menu navigasi diklik
        bottomNav.setOnItemSelectedListener(new BottomNavigationView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                Fragment selectedFragment = null;
                int id = item.getItemId();

                // Cek menu mana yang diklik berdasarkan ID di bottom_nav_menu.xml
                if (id == R.id.nav_home) {
                    selectedFragment = new HomeFragment();
                } else if (id == R.id.nav_kantong) {
                    selectedFragment = new KantongFragment();
                } else if (id == R.id.nav_target) {
                    selectedFragment = new TargetFragment();
                } else if (id == R.id.nav_tagihan) {
                    selectedFragment = new TagihanFragment();
                } else if (id == R.id.nav_profil) {
                    selectedFragment = new ProfilFragment();
                }

                // Jika fragment ditemukan, lakukan penggantian tampilan
                if (selectedFragment != null) {
                    getSupportFragmentManager().beginTransaction()
                        .replace(R.id.fragment_container, selectedFragment)
                        .commit();
                }
                
                return true; // Mengembalikan true agar item terlihat "terpilih" (berwarna aktif)
            }
        });
    }
}