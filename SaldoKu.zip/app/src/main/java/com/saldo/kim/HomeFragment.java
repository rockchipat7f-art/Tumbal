package com.saldo.kim;

import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.appcompat.widget.SwitchCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.ArrayList;
import java.util.List;

public class HomeFragment extends Fragment {

    private TextView tvTotalSaldo, tvTotalMasuk, tvTotalKeluar;
    private DatabaseHelper dbHelper;
    private RecyclerView rvTransaksi;
    private TransaksiAdapter adapter;
    private List<Transaksi> listTransaksi;
    private SwitchCompat switchDarkMode;
    private View rootLayout;
    
    // VARIABEL KUNCI: Untuk memfilter data
    private int idKantongUtama = -1; 

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        rootLayout = view;
        tvTotalSaldo = view.findViewById(R.id.tv_total_saldo);
        tvTotalMasuk = view.findViewById(R.id.tv_total_masuk);
        tvTotalKeluar = view.findViewById(R.id.tv_total_keluar);
        rvTransaksi = view.findViewById(R.id.rv_transaksi);
        switchDarkMode = view.findViewById(R.id.switch_dark_mode);
        
        dbHelper = new DatabaseHelper(getContext());
        listTransaksi = new ArrayList<>();

        rvTransaksi.setLayoutManager(new LinearLayoutManager(getContext()));

        updateBackgroundMode();
        switchDarkMode.setChecked(AppCompatDelegate.getDefaultNightMode() == AppCompatDelegate.MODE_NIGHT_YES);
        switchDarkMode.setOnCheckedChangeListener((button, isChecked) -> {
            if (isChecked) {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
            } else {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
            }
            if (getActivity() != null) getActivity().recreate();
        });

        // BUTTON INPUT MASUK (Kirim ID Kantong Aktif)
        view.findViewById(R.id.btn_masuk).setOnClickListener(v -> {
            Intent intent = new Intent(getContext(), InputSaldoActivity.class);
            intent.putExtra("TIPE", "Masuk");
            intent.putExtra("MODE", "BARU");
            intent.putExtra("KANTONG_ID", idKantongUtama); 
            startActivity(intent);
        });

        // BUTTON INPUT KELUAR (Kirim ID Kantong Aktif)
        view.findViewById(R.id.btn_keluar).setOnClickListener(v -> {
            Intent intent = new Intent(getContext(), InputSaldoActivity.class);
            intent.putExtra("TIPE", "Keluar");
            intent.putExtra("MODE", "BARU");
            intent.putExtra("KANTONG_ID", idKantongUtama);
            startActivity(intent);
        });

        refreshUI();
        return view;
    }

    private void refreshUI() {
        cariIdKantongUtama(); // 1. Cari dulu siapa yang aktif
        updateSaldoDisplay();  // 2. Update angka saldo kantong itu
        loadDataTransaksi();   // 3. Load riwayat kantong itu saja
    }

    private void cariIdKantongUtama() {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT id FROM table_kantong WHERE is_utama = 1 LIMIT 1", null);
        if (cursor != null && cursor.moveToFirst()) {
            idKantongUtama = cursor.getInt(0);
            cursor.close();
        }
    }

    private void updateSaldoDisplay() {
        if (idKantongUtama == -1) return;

        SQLiteDatabase db = dbHelper.getReadableDatabase();
        DecimalFormatSymbols symbols = new DecimalFormatSymbols();
        symbols.setGroupingSeparator('.');
        DecimalFormat df = new DecimalFormat("#,###", symbols);

        // 1. Saldo Kantong Tertentu
        Cursor cursorSaldo = db.rawQuery("SELECT saldo FROM table_kantong WHERE id = ?", new String[]{String.valueOf(idKantongUtama)});
        long saldo = 0;
        if (cursorSaldo.moveToFirst()) saldo = cursorSaldo.getLong(0);
        tvTotalSaldo.setText("Rp. " + df.format(saldo) + ",-");
        cursorSaldo.close();

        // 2. Total Masuk (Hanya untuk kantong ini)
        Cursor cursorMasuk = db.rawQuery("SELECT SUM(nominal) FROM table_transaksi WHERE nominal > 0 AND id_kantong = ?", new String[]{String.valueOf(idKantongUtama)});
        long masuk = 0;
        if (cursorMasuk.moveToFirst()) masuk = cursorMasuk.getLong(0);
        tvTotalMasuk.setText("Rp. " + df.format(masuk));
        cursorMasuk.close();

        // 3. Total Keluar (Hanya untuk kantong ini)
        Cursor cursorKeluar = db.rawQuery("SELECT SUM(ABS(nominal)) FROM table_transaksi WHERE nominal < 0 AND id_kantong = ?", new String[]{String.valueOf(idKantongUtama)});
        long keluar = 0;
        if (cursorKeluar.moveToFirst()) keluar = cursorKeluar.getLong(0);
        tvTotalKeluar.setText("Rp. " + df.format(keluar));
        cursorKeluar.close();
    }

    private void loadDataTransaksi() {
        if (idKantongUtama == -1) return;

        listTransaksi.clear();
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        
        // FILTER: Hanya ambil yang id_kantong-nya cocok!
        Cursor cursor = db.rawQuery("SELECT id, keterangan, nominal, tanggal FROM table_transaksi WHERE id_kantong = ? ORDER BY id DESC", new String[]{String.valueOf(idKantongUtama)});
        
        if (cursor != null && cursor.moveToFirst()) {
            do {
                listTransaksi.add(new Transaksi(cursor.getInt(0), cursor.getString(1), cursor.getLong(2), cursor.getString(3)));
            } while (cursor.moveToNext());
            cursor.close();
        }

        adapter = new TransaksiAdapter(listTransaksi, new TransaksiAdapter.OnItemClickListener() {
            @Override 
            public void onItemClick(Transaksi t) { 
                final EditText etKet = new EditText(getContext());
                etKet.setHint("Ketik keterangan baru...");
                etKet.setSingleLine(true);
                
                FrameLayout container = new FrameLayout(getContext());
                FrameLayout.LayoutParams params = new  FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                params.leftMargin = 60; 
                params.rightMargin = 60;
                params.topMargin = 20;
                etKet.setLayoutParams(params);
                container.addView(etKet);

                new AlertDialog.Builder(getContext())
                    .setTitle("Ubah Keterangan")
                    .setView(container)
                    .setPositiveButton("Simpan", (dialog, which) -> {
                        String input = etKet.getText().toString().trim();
                        if (!input.isEmpty()) {
                            updateKeteranganHanya(t.id, input);
                        }
                    })
                    .setNegativeButton("Batal", null)
                    .show();
            }

            @Override 
            public void onItemLongClick(Transaksi t) { 
                showHapusDialog(t);
            }
        });
        rvTransaksi.setAdapter(adapter);
    }

    private void updateKeteranganHanya(int id, String ketBaru) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("keterangan", ketBaru);
        db.update("table_transaksi", values, "id=?", new String[]{String.valueOf(id)});
        refreshUI();
        Toast.makeText(getContext(), "Teks diperbarui", Toast.LENGTH_SHORT).show();
    }

    private void showHapusDialog(Transaksi t) {
        new AlertDialog.Builder(getContext())
            .setTitle("Hapus Transaksi")
            .setMessage("Yakin mau hapus '" + t.keterangan + "'?")
            .setPositiveButton("Hapus", (d, w) -> {
                SQLiteDatabase db = dbHelper.getWritableDatabase();
                db.beginTransaction();
                try {
                    long nominalLama = t.nominal;
                    db.delete("table_transaksi", "id=?", new String[]{String.valueOf(t.id)});
                    // Update saldo ke kantong yang benar
                    db.execSQL("UPDATE table_kantong SET saldo = saldo - (" + nominalLama + ") WHERE id = " + idKantongUtama);
                    db.setTransactionSuccessful();
                    Toast.makeText(getContext(), "Berhasil dihapus", Toast.LENGTH_SHORT).show();
                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    db.endTransaction();
                }
                refreshUI();
            })
            .setNegativeButton("Batal", null)
            .show();
    }

    private void updateBackgroundMode() {
        int nightModeFlags = getContext().getResources().getConfiguration().uiMode & android.content.res.Configuration.UI_MODE_NIGHT_MASK;
        if (nightModeFlags == android.content.res.Configuration.UI_MODE_NIGHT_YES) {
            rootLayout.setBackgroundColor(Color.parseColor("#262626"));
        } else {
            rootLayout.setBackgroundColor(Color.parseColor("#F5F5F5"));
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        refreshUI();
    }
}