package com.saldo.kim;

import android.app.Activity;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;

public class WidgetSelectionActivity extends Activity {

    private DatabaseHelper dbHelper;
    private List<Integer> listId = new ArrayList<>();
    private List<String> listNama = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        // Kita set judul popupnya
        setTitle("Pilih Kantong");

        dbHelper = new DatabaseHelper(this);
        
        // 1. Ambil semua kantong dari DB
        muatDataKantong();

        if (listNama.isEmpty()) {
            finish(); // Tutup kalau gak ada data
            return;
        }

        // 2. Tampilan List (Sederhana saja pakai ListView bawaan Android)
        ListView listView = new ListView(this);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, listNama);
        listView.setAdapter(adapter);

        setContentView(listView);

        // 3. Aksi saat Nama Kantong dipilih
        listView.setOnItemClickListener((parent, view, position, id) -> {
            int idTerpilih = listId.get(position);

            // Simpan ID yang dipilih ke SharedPreferences
            SharedPreferences prefs = getSharedPreferences("SaldoPrefs", Context.MODE_PRIVATE);
            prefs.edit().putInt("selected_kantong_id", idTerpilih).apply();

            // Beritahu SaldoWidgetProvider buat refresh tampilan
            Intent intent = new Intent(this, SaldoWidgetProvider.class);
            intent.setAction(AppWidgetManager.ACTION_APPWIDGET_UPDATE);
            int[] ids = AppWidgetManager.getInstance(getApplication())
                    .getAppWidgetIds(new ComponentName(getApplication(), SaldoWidgetProvider.class));
            intent.putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, ids);
            sendBroadcast(intent);

            // Tutup Popup
            finish();
        });
    }

    private void muatDataKantong() {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT id, nama_kantong FROM table_kantong", null);
        
        if (cursor.moveToFirst()) {
            do {
                listId.add(cursor.getInt(0));
                listNama.add(cursor.getString(1));
            } while (cursor.moveToNext());
        }
        cursor.close();
    }
}