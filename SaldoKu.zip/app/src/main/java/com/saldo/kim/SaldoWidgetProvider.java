package com.saldo.kim;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.widget.RemoteViews;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;

public class SaldoWidgetProvider extends AppWidgetProvider {

    private static final String ACTION_TOGGLE_PRIVACY = "com.saldo.kim.TOGGLE_PRIVACY";
    // Tambahkan Action Baru untuk Switch
    private static final String ACTION_OPEN_SELECTOR = "com.saldo.kim.OPEN_SELECTOR";

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        for (int appWidgetId : appWidgetIds) {
            updateAppWidget(context, appWidgetManager, appWidgetId);
        }
    }

    static void updateAppWidget(Context context, AppWidgetManager appWidgetManager, int appWidgetId) {
        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.widget_saldo);
        
        // 1. Ambil ID Terpilih dari SharedPreferences (Default 0 artinya cari yang Utama)
        SharedPreferences prefs = context.getSharedPreferences("SaldoPrefs", Context.MODE_PRIVATE);
        int idTerpilih = prefs.getInt("selected_kantong_id", -1);
        boolean isHidden = prefs.getBoolean("privacy_mode", false);

        DatabaseHelper dbHelper = new DatabaseHelper(context);
        SQLiteDatabase db = null;
        Cursor cursor = null;
        long saldoAsli = 0;
        String namaKantong = "Tidak Ada Data";
        int idKantongDitemukan = -1;

        try {
            db = dbHelper.getReadableDatabase();
            // Jika belum ada ID terpilih, ambil yang 'is_utama'
            if (idTerpilih == -1) {
                cursor = db.rawQuery("SELECT id, nama_kantong, saldo FROM table_kantong WHERE is_utama = 1 LIMIT 1", null);
            } else {
                cursor = db.rawQuery("SELECT id, nama_kantong, saldo FROM table_kantong WHERE id = ?", new String[]{String.valueOf(idTerpilih)});
            }
            
            if (cursor != null && cursor.moveToFirst()) {
                idKantongDitemukan = cursor.getInt(0);
                namaKantong = cursor.getString(1);
                saldoAsli = cursor.getLong(2);
                
                // Simpan ID yang benar-benar aktif sekarang ke prefs (biar konsisten)
                prefs.edit().putInt("selected_kantong_id", idKantongDitemukan).apply();
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (cursor != null) cursor.close();
            if (db != null) db.close();
        }

        // 2. Tampilan (Privacy Mode)
        if (isHidden) {
            views.setTextViewText(R.id.tv_saldo_display, "Rp. ****");
            views.setTextViewText(R.id.tv_kantong_name, "***");
            views.setImageViewResource(R.id.btn_privacy, android.R.drawable.ic_menu_close_clear_cancel);
        } else {
            DecimalFormatSymbols symbols = new DecimalFormatSymbols();
            symbols.setGroupingSeparator('.');
            DecimalFormat df = new DecimalFormat("#,###", symbols);
            views.setTextViewText(R.id.tv_saldo_display, "Rp. " + df.format(saldoAsli));
            views.setTextViewText(R.id.tv_kantong_name, namaKantong);
            views.setImageViewResource(R.id.btn_privacy, android.R.drawable.ic_menu_view);
        }

        // 3. Pending Intents
        
        // PRIVACY TOGGLE
        Intent intentPrivacy = new Intent(context, SaldoWidgetProvider.class);
        intentPrivacy.setAction(ACTION_TOGGLE_PRIVACY);
        views.setOnClickPendingIntent(R.id.btn_privacy, 
                PendingIntent.getBroadcast(context, 100, intentPrivacy, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE));

        // KANTONG SWITCH (Membuka Popup/Activity Pilihan)
        // Kita gunakan WidgetSelectionActivity yang akan kita buat
        Intent intentSwitch = new Intent(context, WidgetSelectionActivity.class);
        intentSwitch.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        views.setOnClickPendingIntent(R.id.btn_switch_kantong, 
                PendingIntent.getActivity(context, 103, intentSwitch, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE));

        // TOMBOL MASUK (Kirim ID yang sedang tampil!)
        Intent intentMasuk = new Intent(context, InputSaldoActivity.class);
        intentMasuk.putExtra("TIPE", "Masuk");
        intentMasuk.putExtra("ID_KANTONG", idKantongDitemukan); // <--- INI BIAR GAK ERROR LAGI
        intentMasuk.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_NO_ANIMATION);
        views.setOnClickPendingIntent(R.id.btn_masuk, 
                PendingIntent.getActivity(context, 101, intentMasuk, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE));

        // TOMBOL KELUAR (Kirim ID yang sedang tampil!)
        Intent intentKeluar = new Intent(context, InputSaldoActivity.class);
        intentKeluar.putExtra("TIPE", "Keluar");
        intentKeluar.putExtra("ID_KANTONG", idKantongDitemukan); // <--- INI JUGA
        intentKeluar.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_NO_ANIMATION);
        views.setOnClickPendingIntent(R.id.btn_keluar, 
                PendingIntent.getActivity(context, 102, intentKeluar, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE));

        // REFRESH
        Intent intentUpdate = new Intent(context, SaldoWidgetProvider.class);
        intentUpdate.setAction(AppWidgetManager.ACTION_APPWIDGET_UPDATE);
        intentUpdate.putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, new int[]{appWidgetId});
        views.setOnClickPendingIntent(R.id.btn_update, 
                PendingIntent.getBroadcast(context, appWidgetId, intentUpdate, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE));

        appWidgetManager.updateAppWidget(appWidgetId, views);
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);
        if (ACTION_TOGGLE_PRIVACY.equals(intent.getAction())) {
            SharedPreferences prefs = context.getSharedPreferences("SaldoPrefs", Context.MODE_PRIVATE);
            boolean isHidden = prefs.getBoolean("privacy_mode", false);
            prefs.edit().putBoolean("privacy_mode", !isHidden).apply();

            refreshWidget(context);
        }
    }
    
    // Fungsi pembantu buat refresh tampilan widget dari mana saja
    public static void refreshWidget(Context context) {
        AppWidgetManager mgr = AppWidgetManager.getInstance(context);
        ComponentName name = new ComponentName(context, SaldoWidgetProvider.class);
        int[] ids = mgr.getAppWidgetIds(name);
        for (int id : ids) {
            updateAppWidget(context, mgr, id);
        }
    }
}