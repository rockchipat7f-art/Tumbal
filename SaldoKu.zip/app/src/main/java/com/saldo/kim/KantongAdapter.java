package com.saldo.kim;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.List;

public class KantongAdapter extends RecyclerView.Adapter<KantongAdapter.ViewHolder> {

    private List<Kantong> listKantong;
    private Context context;
    private DatabaseHelper dbHelper;
    private OnItemLongClickListener longClickListener;

    public interface OnItemLongClickListener {
        void onItemLongClick(Kantong k);
    }

    public void setOnItemLongClickListener(OnItemLongClickListener listener) {
        this.longClickListener = listener;
    }

    public KantongAdapter(List<Kantong> listKantong, Context context) {
        this.listKantong = listKantong;
        this.context = context;
        this.dbHelper = new DatabaseHelper(context);
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.item_kantong, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Kantong k = listKantong.get(position);
        
        holder.tvNama.setText(k.nama);
        
        DecimalFormatSymbols symbols = new DecimalFormatSymbols();
        symbols.setGroupingSeparator('.');
        DecimalFormat df = new DecimalFormat("#,###", symbols);
        holder.tvSaldo.setText("Rp. " + df.format(k.saldo));

        // Logika Tampilan & Warna
        if (k.isUtama == 1) {
            holder.btnSetUtama.setText("✓ Kantong Utama");
            // Menggunakan ContextCompat agar tidak deprecated
            holder.btnSetUtama.setTextColor(ContextCompat.getColor(context, android.R.color.darker_gray));
            holder.btnSetUtama.setEnabled(false);
        } else {
            holder.btnSetUtama.setText("Jadikan Kantong Utama");
            holder.btnSetUtama.setTextColor(ContextCompat.getColor(context, android.R.color.holo_blue_dark));
            holder.btnSetUtama.setEnabled(true);
        }

        holder.btnSetUtama.setOnClickListener(v -> setAsUtama(k.id));
        
        holder.itemView.setOnLongClickListener(v -> {
            if (longClickListener != null) {
                longClickListener.onItemLongClick(k);
            }
            return true;
        });
    }

    private void setAsUtama(int id) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        db.beginTransaction();
        try {
            db.execSQL("UPDATE table_kantong SET is_utama = 0");
            db.execSQL("UPDATE table_kantong SET is_utama = 1 WHERE id = " + id);
            
            db.setTransactionSuccessful();
            Toast.makeText(context, "Berhasil pindah kantong utama!", Toast.LENGTH_SHORT).show();
            
            // Refresh data otomatis lewat MainActivity jika perlu
            if (context instanceof MainActivity) {
                // Pastikan tag fragment-nya benar jika Mamang pakai tag saat transaksi fragment
                // Jika tidak, notifyDataSetChanged() di bawah sudah cukup untuk visual list
            }
            
            notifyDataSetChanged(); 

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            db.endTransaction();
        }
    }

    @Override
    public int getItemCount() {
        return listKantong.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvNama, tvSaldo, btnSetUtama;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvNama = itemView.findViewById(R.id.tv_nama_kantong);
            tvSaldo = itemView.findViewById(R.id.tv_saldo_kantong);
            btnSetUtama = itemView.findViewById(R.id.btn_set_utama);
        }
    }
}