package com.saldo.kim;

import android.app.Activity;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class InputSaldoActivity extends Activity {

    private int idTransaksi = -1;
    private int idKantongAktif = -1; 
    private String mode = "BARU";
    private long nominalLama = 0;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dialog_input);

        dbHelper = new DatabaseHelper(this);

        EditText etNominal = findViewById(R.id.et_nominal);
        EditText etKeterangan = findViewById(R.id.et_keterangan); // Kolom Baru
        Button btnSimpan = findViewById(R.id.btn_simpan);
        TextView tvTitle = findViewById(R.id.tv_title_dialog);

        Intent intent = getIntent();
        mode = intent.getStringExtra("MODE");
        if (mode == null) mode = "BARU";

        String tipe = intent.getStringExtra("TIPE");
        if (tipe == null) tipe = "Masuk";

        idKantongAktif = intent.getIntExtra("ID_KANTONG", -1);

        if (idKantongAktif == -1) {
            idKantongAktif = getIdKantongUtama();
        }

        if ("EDIT".equals(mode)) {
            idTransaksi = intent.getIntExtra("ID", -1);
            nominalLama = intent.getLongExtra("NOM", 0);
            String ketLama = intent.getStringExtra("KET"); // Tangkap keterangan lama jika ada
            
            tvTitle.setText("Edit Transaksi");
            btnSimpan.setText("Update");
            etNominal.setText(String.valueOf(Math.abs(nominalLama)));
            if (ketLama != null) etKeterangan.setText(ketLama);
        } else {
            tvTitle.setText("Input " + tipe);
            btnSimpan.setText("Simpan");
        }

        final String finalTipe = tipe;

        btnSimpan.setOnClickListener(v -> {
            String inputNominal = etNominal.getText().toString().trim();
            String inputKeterangan = etKeterangan.getText().toString().trim(); // Ambil input keterangan

            if (inputNominal.isEmpty()) {
                Toast.makeText(this, "Nominal wajib diisi, Wak!", Toast.LENGTH_SHORT).show();
                return;
            }

            if (idKantongAktif == -1) {
                Toast.makeText(this, "Waduh, ID Kantong gak ketemu!", Toast.LENGTH_SHORT).show();
                return;
            }

            try {
                long nominalInput = Long.parseLong(inputNominal);
                long nominalBaru = finalTipe.equalsIgnoreCase("Keluar") ? -nominalInput : nominalInput;

                // Logika Opsional: Jika keterangan kosong, pakai default
                String keteranganFinal;
                if (inputKeterangan.isEmpty()) {
                    keteranganFinal = finalTipe + " (Widget)";
                } else {
                    keteranganFinal = inputKeterangan;
                }

                SQLiteDatabase db = dbHelper.getWritableDatabase();
                db.beginTransaction(); 
                try {
                    // 1. Update Saldo di Table Kantong
                    db.execSQL("UPDATE table_kantong SET saldo = saldo - (" + nominalLama + ") + (" + nominalBaru + ") WHERE id = " + idKantongAktif);

                    // 2. Simpan/Update Riwayat di Table Transaksi
                    ContentValues vTransaksi = new ContentValues();
                    vTransaksi.put("nominal", nominalBaru);
                    vTransaksi.put("id_kantong", idKantongAktif);
                    vTransaksi.put("keterangan", keteranganFinal); // Simpan keterangannya di sini
                    
                    if ("EDIT".equals(mode)) {
                        db.update("table_transaksi", vTransaksi, "id=?", new String[]{String.valueOf(idTransaksi)});
                        Toast.makeText(this, "Berhasil diupdate!", Toast.LENGTH_SHORT).show();
                    } else {
                        db.insert("table_transaksi", null, vTransaksi);
                        Toast.makeText(this, "Catatan disimpan!", Toast.LENGTH_SHORT).show();
                    }

                    db.setTransactionSuccessful();
                } finally {
                    db.endTransaction();
                }

                SaldoWidgetProvider.refreshWidget(this);
                finish();

            } catch (Exception e) {
                Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private int getIdKantongUtama() {
        int id = -1;
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT id FROM table_kantong WHERE is_utama = 1 LIMIT 1", null);
        if (cursor.moveToFirst()) id = cursor.getInt(0);
        cursor.close();
        return id;
    }
}