package com.saldo.kim;

public class Kantong {
    public int id;
    public String nama;
    public long saldo;
    public int isUtama; // 1 = Utama, 0 = Biasa

    // Constructor untuk memudahkan ambil data dari Database
    public Kantong(int id, String nama, long saldo, int isUtama) {
        this.id = id;
        this.nama = nama;
        this.saldo = saldo;
        this.isUtama = isUtama;
    }
}